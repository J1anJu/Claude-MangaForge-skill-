#!/bin/bash
# Status line for Claude Code terminal

# Colors
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RESET='\033[0m'

# Get current context
if [ -f ".claude/active.md" ]; then
  STAGE=$(grep -E "^## Stage:" .claude/active.md 2>/dev/null | head -1 | sed 's/## Stage: //')
  EPIC=$(grep -E "^\*\*Epic\*\*:" .claude/active.md 2>/dev/null | head -1 | sed 's/\*\*Epic\*\*: //')
  STORY=$(grep -E "^\*\*Story\*\*:" .claude/active.md 2>/dev/null | head -1 | sed 's/\*\*Story\*\*: //')

  [ -z "$STAGE" ] && STAGE="Unknown"
  [ -z "$EPIC" ] && EPIC="No epic"
  [ -z "$STORY" ] && STORY="No story"
else
  STAGE="No active session"
  EPIC="-"
  STORY="-"
fi

# Git branch
if git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
  BRANCH=$(git branch --show-current)
  GIT_INFO=" [$BRANCH]"
else
  GIT_INFO=""
fi

# Model info (from environment or default)
MODEL="${ANTHROPIC_MODEL:-auto}"

# Build status line
STATUS="${CYAN}Stage:${RESET} $STAGE | ${GREEN}Epic:${RESET} $EPIC | ${YELLOW}Story:${RESET} $STORY${GIT_INFO} | Model: $MODEL"

echo "$STATUS"
