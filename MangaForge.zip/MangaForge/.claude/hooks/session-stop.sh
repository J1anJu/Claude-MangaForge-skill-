#!/bin/bash
# Session stop hook - archive progress

set -e

# Archive active.md if exists
if [ -f ".claude/active.md" ]; then
  mkdir -p ".claude/session-logs"
  TIMESTAMP=$(date +%Y%m%d-%H%M%S)
  cp ".claude/active.md" ".claude/session-logs/session-${TIMESTAMP}.md"
fi

# Record git activity since last session
if git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
  echo ""
  echo "Session completed. Git status:"
  git status --short
fi

echo ""
echo "Session archived. Next time: /skill-test to verify skills."
