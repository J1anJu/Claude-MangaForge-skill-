#!/bin/bash
# Validate assets after Write/Edit operations
# Only fires for files in design-system/ or assets/ directories

set -e

FILE_PATH="$1"

# Only validate files in these directories
if [[ ! "$FILE_PATH" =~ ^design-system/ ]] && [[ ! "$FILE_PATH" =~ ^assets/ ]]; then
  exit 0
fi

# Check design-system file structure
if [[ "$FILE_PATH" =~ ^design-system/ ]]; then
  # MASTER.md must have all required sections
  if [[ "$FILE_PATH" == "design-system/MASTER.md" ]]; then
    if ! grep -q "PATTERN:" "$FILE_PATH"; then
      echo "ERROR: MASTER.md missing PATTERN section"
      exit 1
    fi
    if ! grep -q "COLORS:" "$FILE_PATH"; then
      echo "ERROR: MASTER.md missing COLORS section"
      exit 1
    fi
    if ! grep -q "TYPOGRAPHY:" "$FILE_PATH"; then
      echo "ERROR: MASTER.md missing TYPOGRAPHY section"
      exit 1
    fi
  fi
fi

# Check assets naming
if [[ "$FILE_PATH" =~ ^assets/ ]]; then
  # Assets should use kebab-case
  BASENAME=$(basename "$FILE_PATH")
  if echo "$BASENAME" | grep -q "[A-Z]"; then
    echo "WARNING: Asset filename contains uppercase. Use kebab-case: ${BASENAME,,}"
  fi
fi

exit 0
