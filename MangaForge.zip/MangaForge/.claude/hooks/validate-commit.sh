#!/bin/bash
# Pre-commit validation
# Exits early (0) if not a git commit command

set -e

# Only run on git commit
if [[ "$*" != "git commit"* ]]; then
  exit 0
fi

# Check for TODO/FIXME without issue reference
if git diff --cached --patch | grep -E "(TODO|FIXME|HACK):" | grep -vq "#[0-9]+"; then
  echo "WARNING: TODO/FIXME should reference an issue number"
  echo "Example: TODO #123 fix this after investigation"
fi

# Check for hardcoded values (config should use constants)
if git diff --cached --patch | grep -E "(apiUrl|API_URL|secret|password|token)" | grep -v ".env" > /dev/null; then
  echo "ERROR: Hardcoded credentials/URLs detected!"
  echo "Use environment variables or constants instead."
  exit 1
fi

# Type checking before commit (optional - uncomment to enforce)
# pnpm typecheck

exit 0
