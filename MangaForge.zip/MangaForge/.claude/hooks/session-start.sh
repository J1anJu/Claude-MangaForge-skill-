#!/bin/bash
# Session start hook - show context

echo "================================================"
echo "  MangaReader Powers - Session Start"
echo "================================================"
echo ""

# Show current git branch
if git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
  BRANCH=$(git branch --show-current)
  echo "📌 Current branch: $BRANCH"

  # Show recent commits
  echo ""
  echo "Recent commits:"
  git log --oneline -5
fi

echo ""
echo "Available skills:"
echo "  • manga-brainstorming   - Feature planning"
echo "  • manga-design-system   - UI/UX design"
echo "  • manga-gamification    - Achievements & stats"
echo "  • manga-continuity      - Reading tracking"
echo "  • manga-qa             - Quality assurance"
echo "  • manga-release        - Deployment"
echo ""
echo "Agents:"
echo "  • creative-director    - Design & UX"
echo "  • technical-director   - Architecture"
echo "  • qa-specialist        - Testing & quality"
echo "  • ui-programmer        - Vue implementation"
echo ""
echo "Design system:"
if [ -f "design-system/MASTER.md" ]; then
  echo "  ✓ Loaded from design-system/MASTER.md"
else
  echo "  ⚠ No design system yet. Use:"
  echo "     python3 .claude/skills/ui-ux-pro-max/scripts/search.py \"manga reading app\" --design-system --persist -p \"MangaReader\""
fi
echo ""
echo "================================================"
