#!/bin/bash
# Warn to test skill after modifying skill files

set -e

FILE_PATH="$1"

# Only fire on edits to .claude/skills/
if [[ ! "$FILE_PATH" =~ \.claude/skills/ ]]; then
  exit 0
fi

echo "NOTE: Skill files modified. Consider running:"
echo "  /skill-test"
echo "to verify skill behavior."

exit 0
