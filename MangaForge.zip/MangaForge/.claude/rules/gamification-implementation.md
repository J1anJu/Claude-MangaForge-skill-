---
path: "packages/web/src/stores/**/*gamification*"
name: "gamification-implementation"
description: "Implementation standards for gamification features in manga reader"
---

# Gamification Implementation Rules / 游戏化实现规范

## Applies To / 适用范围

All gamification-related code:
- Stores: `stores/useGamificationStore.ts`, `stores/useAchievementStore.ts`
- Services: `services/achievement-service.ts`, `services/streak-service.ts`
- Composables: `composables/useReadingStats.ts`
- Types: `shared/src/types/gamification.ts`

## Core Principles / 核心原则

1. **Atomic Transactions** - Never leave achievement/streak half-updated
2. **Local-First** - Writes complete synchronously, sync to cloud async
3. **User Privacy** - All gamification data opt-in, easily exportable/erasable
4. **Non-Intrusive** - Enhance reading, don't disrupt it

## Achievement System / 成就系统

### Data Model / 数据模型

```typescript
// shared/src/types/gamification.ts
export interface AchievementDefinition {
  /** Stable identifier, never change once published */
  id: string
  /** User-facing title */
  title: string
  /** Description of what this achievement recognizes */
  description: string
  /** Icon name from our icon library */
  icon: IconName
  /** Category for grouping/filtering */
  category: 'reading' | 'exploration' | 'collection' | 'social'
  /** Rarity (for sorting/filtering) */
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary'

  /** Condition that must be met to unlock */
  condition: {
    type: 'cumulative' | 'single' | 'streak' | 'completion'
    metric: 'chapters' | 'pages' | 'series' | 'genres' | 'days' | 'minutes'
    operator: 'gte' | 'eq' | 'gt'  // >=, ==, >
    target: number
    /** For conditional achievements */
    requires?: string[]  // Other achievement IDs that must be unlocked first
    /** For streak achievements */
    consecutiveDays?: number  // e.g., 7 for "7-day streak"
    /** For genre exploration */
    unique?: boolean  // Count unique only
  }

  /** Show progress bar before unlocking? */
  progressive?: boolean

  /** Hidden until unlocked? (secret achievements) */
  hidden?: boolean

  /** For display ordering */
  sortOrder: number
}

export interface UnlockedAchievement {
  achievementId: string
  unlockedAt: Date
  /** Snapshot of progress at unlock time (for progressive) */
  progressSnapshot?: number
}
```

### Unlocking Flow / 解锁流程

```typescript
// services/achievement-service.ts
export class AchievementService {
  constructor(
    private db: GamificationDB,
    private eventBus: EventBus
  ) {}

  async checkAndUnlock(metric: string, value: number): Promise<UnlockedAchievement[]> {
    const newlyUnlocked: UnlockedAchievement[] = []

    for (const def of this.definitions) {
      // Skip if already unlocked
      if (await this.isUnlocked(def.id)) continue

      // Check hidden prerequisites
      if (def.condition.requires) {
        const hasPrereqs = await Promise.all(
          def.condition.requires.map(id => this.isUnlocked(id))
        )
        if (!hasPrereqs.every(Boolean)) continue
      }

      // Evaluate condition
      const meetsCondition = this.evaluateCondition(def.condition, metric, value)
      if (!meetsCondition) continue

      // Atomic unlock
      await this.unlock(def)
      newlyUnlocked.push({
        achievementId: def.id,
        unlockedAt: new Date()
      })

      // Broadcast event
      this.eventBus.emit('achievement.unlocked', { achievementId: def.id })
    }

    return newlyUnlocked
  }

  private evaluateCondition(
    condition: AchievementDefinition['condition'],
    metric: string,
    value: number
  ): boolean {
    if (condition.metric !== metric) return false

    switch (condition.operator) {
      case 'gte': return value >= condition.target
      case 'eq': return value === condition.target
      case 'gt': return value > condition.target
      default: return false
    }
  }

  private async unlock(def: AchievementDefinition): Promise<void> {
    // Atomic transaction - all or nothing
    await this.db.transaction('rw', [this.db.unlockedAchievements], async () => {
      await this.db.unlockedAchievements.add({
        achievementId: def.id,
        unlockedAt: new Date()
      })
    })
  }
}
```

**Performance**: Entire check cycle < 5ms (cache definitions in memory).

## Streak Calculation / 连续阅读计算

### Rules / 规则

- **Date-based**: Based on calendar days, not 24h periods
- **Timezone**: Use user's local timezone (from browser/device)
- **Maintenance**: Any reading activity on a day counts toward streak
- **Break**: Missing a single day resets streak to 0

### Implementation / 实现

```typescript
// services/streak-service.ts
export interface DailyRead {
  date: string  // YYYY-MM-DD in user's local date
  chaptersRead: number
  goalMet: boolean
}

export class StreakService {
  calculateCurrentStreak(dailyReads: DailyRead[]): number {
    // Sort by date descending (most recent first)
    const sorted = [...dailyReads].sort((a, b) =>
      new Date(b.date).getTime() - new Date(a.date).getTime()
    )

    const today = new Date().toISOString().split('T')[0]
    let streak = 0
    let currentDate = new Date(today)

    for (const record of sorted) {
      const recordDate = new Date(record.date).toISOString().split('T')[0]
      const expectedDate = this.addDays(currentDate, -1).toISOString().split('T')[0]

      if (recordDate === currentDate.toISOString().split('T')[0] && record.goalMet) {
        streak++
      } else if (recordDate === expectedDate) {
        currentDate = new Date(recordDate)
        streak++
      } else {
        // Gap detected - break the streak
        break
      }
    }

    return streak
  }

  calculateLongestStreak(dailyReads: DailyRead[]): number {
    // Same algorithm but continue through gaps, track max
    // ...
  }

  private addDays(date: Date, days: number): Date {
    const result = new Date(date)
    result.setDate(result.getDate() + days)
    return result
  }
}
```

### Streak Goal Configuration / 连续目标配置

Allow users to customize daily goal (default: 1 chapter):

```typescript
interface UserStreakSettings {
  dailyGoal: number  // Chapters required to maintain streak
  timezone: string   // IANA timezone: "Asia/Shanghai", "America/New_York"
  gracePeriodHours: number  // Allow reading past midnight (default: 3)
}
```

## XP and Leveling System / XP 和等级系统

### Curve Design / 曲线设计

Exponential growth to maintain engagement:

```
Level   XP Required    Total XP   Increment
1       0             0          N/A
2       100           100        100
3       150           250        150
4       225           475        225
5       338           813        338
10      2,584         9,759      ~2k at level 10
20      65,534        131,069    ~65k at level 20
```

**Formula**:
```typescript
const BASE_XP = 100
const MULTIPLIER = 1.5

function xpToNextLevel(level: number): number {
  return Math.floor(BASE_XP * Math.pow(MULTIPLIER, level - 1))
}

function levelFromTotalXP(totalXP: number): number {
  let level = 1
  let cumulative = 0
  while (cumulative + xpToNextLevel(level) <= totalXP) {
    cumulative += xpToNextLevel(level)
    level++
  }
  return level
}
```

### XP Sources / XP 来源

| Action / 动作 | XP Awarded / 奖励 | Conditions / 条件 |
|---------------|------------------|------------------|
| Complete chapter | 50 | Per chapter |
| Read page (alternative) | 1 | Optional, for granular tracking |
| Maintain streak (daily bonus) | 100 | If streak > 0 |
| Unlock achievement | 200 | One-time per achievement |
| Complete series | 500 | One-time per series |
| Read 10+ chapters in session | 250 | Milestone bonus |

**Implementation Pattern**:
```typescript
async recordChapterComplete(comicId: string): Promise<void> {
  // 1. Add base XP
  await this.addXP(50)

  // 2. Check for achievement triggers
  await this.achievementService.checkAndUnlock('chapters', this.stats.totalChapters + 1)

  // 3. Update stats (will recalc level)
  await this.stats.increment Chapters()
}
```

## Performance Requirements / 性能要求

| Operation / 操作 | Max Time / 最大时间 | Typical / 典型 |
|------------------|---------------------|---------------|
| Check achievements | 5ms | 2ms |
| Calculate streak | 3ms | 1ms |
| XP/level calculation | 1ms | <1ms |
| Stats aggregation | 10ms | 5ms |
| Store transaction | 50ms | 20ms |

**Optimization Strategies**:

1. **Cache definitions in memory**:
   ```typescript
   let achievementCache: AchievementDefinition[] | null = null
   async getAchievements(): Promise<AchievementDefinition[]> {
     if (!achievementCache) {
       achievementCache = await this.db.achievements.toArray()
     }
     return achievementCache
   }
   ```

2. **Debounce frequent updates**:
   ```typescript
   // Reading a chapter may trigger 10+ page events
   // Debounce stats updates to once per second
   const debouncedUpdate = debounce(async () => {
     await this.persistStats()
   }, 1000)
   ```

3. **Batch database writes**:
   ```typescript
   // Collect updates, write in single transaction
   const pendingUpdates: GamificationUpdate[] = []
   function queueUpdate(update: GamificationUpdate) {
     pendingUpdates.push(update)
   }
   async function flushUpdates() {
     await this.db.transaction('rw', [this.db.stats], async () => {
       for (const update of pendingUpdates) {
         await this.applyUpdate(update)
       }
     })
     pendingUpdates.length = 0
   }
   ```

## Data Persistence / 数据持久化

### Dexie Schema / 数据库表结构

```typescript
export class GamificationDB extends Dexie {
  // Static definition tables (populated on install)
  achievements!: Table<AchievementDefinition>
  levels!: Table<{ level: number; xpRequired: number }>

  // User data (per user device, may sync)
  unlockedAchievements!: Table<UnlockedAchievement>
  readingProgress!: Table<DailyReadingRecord>
  streakHistory!: Table<StreakRecord>
  stats!: Table<ReadingStats>
  collections!: Table<SeriesCollection>

  constructor() {
    super('gamification-db')
    this.version(3).stores({
      achievements: 'id, category, rarity, sortOrder',
      levels: 'level',
      unlockedAchievements: '++id, achievementId, unlockedAt, [achievementId+userId]',
      readingProgress: '++id, date, [date+userId]',
      streakHistory: 'userId, date',
      stats: 'userId',
      collections: '++id, comicId, [comicId+userId]'
    })
  }
}
```

### Sync Strategy / 同步策略

**Local-first with optional cloud**:

1. All writes happen locally first (<50ms)
2. Cloud sync happens in background (fire-and-forget)
3. Conflict resolution: newest timestamp wins (last-write-wins)
4. User can export/import JSON for backup/restore

```typescript
async persistStat(key: string, value: number): Promise<void> {
  // 1. Update local (fast)
  await this.db.stats.update('user-id', { [key]: value })

  // 2. Queue for cloud sync (async)
  if (this.cloudEnabled) {
    this.syncQueue.add({ type: 'stat-update', key, value, timestamp: Date.now() })
  }
}
```

## Privacy Considerations / 隐私考虑

- All gamification data stored locally by default
- Cloud sync explicitly opt-in
- User can export all data as JSON
- User can delete gamification data without affecting reading data
- No gamification data included in analytics (unless user consents)

## Visual Design Guidelines / 视觉设计指南

从 `design-system/MASTER.md` 获取规范，特别参考:

- **Achievement icons**: Gold/yellow palette, star shapes, badge forms
- **Streak display**: Fire/ flame icon, warm orange colors
- **Level progress**: Bar indicator, gradient fill
- **Stats dashboard**: Card-based layout (Bento grid pattern)

---

*These rules ensure consistent, performant, secure gamification implementation. All gamification stores must follow these patterns.*
