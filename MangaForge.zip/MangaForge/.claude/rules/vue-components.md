---
path: "packages/web/src/**/*.vue"
name: "vue-components"
description: "Vue 3 best practices for manga reader components"
---

# Vue Component Rules / Vue 组件规则

## Applies To / 适用范围

All `.vue` files under:
- `packages/web/src/components/`
- `packages/web/src/pages/`
- `packages/web/src/views/`

## Component Standards / 组件标准

### 1. Composition API Requirement / 必须使用 Composition API

All components must use `<script setup>` syntax.

```vue
<!-- ✅ CORRECT -->
<script setup lang="ts">
// Your code here
</script>

<!-- ❌ INCORRECT (legacy) -->
<script lang="ts">
export default {
  // Options API
}
</script>
```

### 2. TypeScript Strict Mode / TypeScript 严格模式

All components enforce:
- `strict: true` in tsconfig
- All props typed with interfaces or type literals
- No implicit `any`
- No type assertions (`as any`) without comment justification

**Props Definition**:
```typescript
// ✅ Good - explicit types
const props = defineProps<{
  comicId: string
  chapterId: string
  pageCount: number
  showControls?: boolean  // Optional has ?
  mode?: 'scroll' | 'paged' | 'webtoon'  // Union type
}>()

// ❌ Bad - no types or implicit any
const props = defineProps(['comicId', 'chapterId'])
// OR
const props = defineProps<any>()
```

**Emit Definition**:
```typescript
// ✅ Good
const emit = defineEmits<{
  (e: 'page-change', page: number): void
  (e: 'bookmark'): void
  (e: 'mode-change', mode: ReaderMode): void
}>()

// ❌ Bad - untyped emits
const emit = defineEmits(['change'])
```

### 3. Component Structure Convention / 组件结构约定

Order within `<script setup>`:

```typescript
// 1. Imports (standard library first, then third-party, then local)
import { ref, computed, onMounted } from 'vue'
import { useReaderStore } from '@/stores/reader'
import type { Comic } from '@shared/types'

// 2. Props
const props = defineProps<{ /* ... */ }>()

// 3. Emits
const emit = defineEmits<{ /* ... */ }>()

// 4. Refs and reactive state (local only)
const currentPage = ref(0)
const isLoaded = ref(false)

// 5. Computed properties (derived state)
const totalPages = computed(() => props.pageCount)
const progress = computed(() => currentPage.value / totalPages.value)

// 6. Stores (Pinia)
const readerStore = useReaderStore()

// 7. Lifecycle hooks
onMounted(() => {
  initializeReader()
})

// 8. Functions/methods (business logic)
function goToPage(page: number) {
  currentPage.value = page
  emit('page-change', page)
}
```

### 4. State Management Patterns / 状态管理模式

#### Local State First
Keep state local to component unless multiple components need it:

```typescript
// ✅ Local state - component owns it
const isLoading = ref(false)  // Only this component cares

// ❌ Premature store - introduces global dependency
const store = useUiStore()
store.isLoading = true  // Other components affected?
```

#### Store Usage Guidelines / 存储使用指南
- **Shared state** → Pinia store (user settings, library data)
- **Server state** → Use composables with caching (vue-query pattern)
- **URL state** → Use `vue-router` query params (shareable URLs)
- **Transient UI state** → Local ref (loading, hover, modals)

**Never** mutate store state directly in components → use store `actions`:

```typescript
// ✅ Correct - use action
await readerStore.setCurrentChapter(chapterId)

// ❌ Wrong - direct mutation (bypasses actions/logic)
readerStore.currentChapterId = chapterId
```

### 5. Accessibility Requirements / 可访问性要求

All interactive elements must be accessible:

**Buttons**:
```vue
<!-- ✅ Use <button> for actions -->
<button @click="handleClick">Save</button>

<!-- ❌ <div> with click handler (no keyboard, no ARIA) -->
<div @click="handleClick">Save</div>
```

**Icons with text** (skip if icon is decorative):
```vue
<!-- ✅ icon with visually-hidden text -->
<button>
  <HomeIcon />
  <span class="sr-only">Home</span>
</button>
```

**Focus Management**:
```typescript
// Modals must return focus on close
const modal = ref<HTMLElement | null>(null)
const previouslyFocused = ref<HTMLElement | null>(null)

onMounted(() => {
  previouslyFocused.value = document.activeElement as HTMLElement
  modal.value?.focus()
})

onUnmounted(() => {
  previouslyFocused.value?.focus()
})
```

**Keyboard Navigation**:
- All interactive elements in `tabindex` order
- Visible `:focus` styles (not browser default)
- `Enter` activates buttons, `Space` sometimes
- Arrow keys for carousel/scroll areas

### 6. Performance Patterns / 性能模式

#### Avoid Large Reactive Objects
```typescript
// ❌ Bad - entire comic object reactive (triggers on any change)
const comic = reactive(comicData)  // comicData has many fields

// ✅ Good - only reactive fields needed
const title = ref(comicData.title)
const coverUrl = ref(comicData.coverUrl)
// Access other fields via comicData directly (no reactivity needed)
```

#### Virtual Scrolling for Long Lists
For `v-for` with > 50 items:

```vue
<!-- Use @tanstack/vue-virtual -->
<template>
  <div>
    <RecycleScroller
      class="scroller"
      :items="items"
      :item-size="80"
      key-field="id"
    >
      <template #default="{ item }">
        <ListItem :item="item" />
      </template>
    </RecycleScroller>
  </div>
</template>
```

#### Lazy Load Images
```vue
<template>
  <!-- ✅ Native lazy loading -->
  <img :src="imageUrl" loading="lazy" alt="..." />

  <!-- OR lazy with placeholder -->
  <img
    :src="isInViewport ? imageUrl : placeholder"
    @IntersectionObserver="isInViewport = true"
  />
</template>
```

#### Memoize Expensive Subtrees / 记忆昂贵子树
```vue
<!-- Vue 3.3+ v-memo -->
<template>
  <!-- This subtree only re-renders when prop changes -->
  <div v-memo="[propA, propB]">
    <ExpensiveComponent :a="propA" :b="propB" />
  </div>
</template>
```

### 7. Component Naming / 组件命名

**File names** (PascalCase for components):
```
ComicCard.vue
ReaderControls.vue
ChapterList.vue
```

**Component registration** (auto-imported via unplugin-vue-components):
No manual `components: {}` needed if configured properly.

If manual registration required:
```typescript
// ✅ PascalCase in definition
const ComicCard = defineComponent({ /* ... */ })

// ✅ kebab-case in template
// <comic-card />
```

### 8. Style Scoping / 样式隔离

Always use `<style scoped>`:
```vue
<style scoped lang="scss">
// Styles only apply to this component
.reader-controls {
  // ...
}
</style>
```

**Global styles** → `packages/web/src/styles/` or `assets/`

**Design system tokens** → CSS custom properties from `design-system/`:
```scss
.button {
  background: var(--color-primary);
  border-radius: var(--radius-md);
}
```

### 9. Responsive Design / 响应式设计

Use Tailwind or SCSS with breakpoints:

```html
<!-- Tailwind -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
  <!-- 1 col mobile, 2 tablet, 4 desktop -->
</div>
```

```scss
// SCSS with breakpoints
.card {
  padding: 16px;

  @media (min-width: 768px) {
    padding: 24px;
  }
}
```

**Recommended breakpoints** (from design system):
- `sm`: 640px
- `md`: 768px
- `lg`: 1024px
- `xl`: 1280px
- `2xl`: 1536px

### 10. Reading Mode Components / 阅读模式组件

Special considerations for reader components:

**Scroll Mode**:
- Use `overflow-y: auto`
- `scroll-behavior: smooth` for anchor jumps
- Preload adjacent images (IntersectionObserver)

**Paged Mode**:
- `scroll-snap-type: x mandatory`
- Each page `scroll-snap-align: start`
- Keyboard: Arrow keys navigate pages

**Webtoon Mode**:
- `flex-direction: column`
- Images `width: 100%, height: auto`
- Smooth scroll without page breaks

**Common**:
- Pinch-to-zoom support
- Double-tap toggle fullscreen
- Orientation change handling

## Testing Requirements / 测试要求

Component tests for:
- Complex state interactions (forms, multi-step)
- Props validation and defaults
- Emit events with correct payloads
- Lifecycle hooks behavior

Skip tests for:
- Pure styling (no logic)
- Simple presentational wrappers
- Third-party components

---

*Adherence to these rules ensures consistent, maintainable, accessible Vue components. Violations fail code review.*
