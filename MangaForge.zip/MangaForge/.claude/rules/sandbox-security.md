---
path: "packages/sandbox/src/**"
name: "sandbox-security"
description: "Enforces security boundaries for source script execution in Web Workers"
---

# Sandbox Security Rules / 沙箱安全规则

## Applies To / 适用范围

All files in `packages/sandbox/src/` including:
- Worker entry points (`worker.ts`)
- Runtime APIs (`runtime.ts`)
- Whitelist management (`whitelist.ts`)
- Script validation (`validator.ts`)

## Critical Security Principles / 核心安全原则

### 1. Complete DOM Isolation / DOM 完全隔离

Web Workers have NO access to DOM APIs. Enforce this absolutely.

**Forbidden Patterns** (Linter should flag):
```typescript
// ❌ ALL OF THESE ARE FORBIDDEN
window.document
window.localStorage
window.sessionStorage
window.location
document.querySelector()
document.createElement()
window.postMessage()    // Use worker-specific messaging only
```

**Why**: Source scripts are untrusted third-party code. Any DOM access is a potential XSS vector.

### 2. Network Request Whitelisting / 网络请求白名单

All external requests must be validated against domain whitelist.

**The `safeFetch` Contract**:
```typescript
// Existing pattern (keep this):
async function safeFetch(allowedDomain: string, url: string, options?: RequestInit) {
  // 1. Validate URL belongs to allowed domain
  const urlObj = new URL(url)
  if (!urlObj.hostname.endsWith(allowedDomain)) {
    throw new Error(`Domain ${urlObj.hostname} not in whitelist`)
  }

  // 2. Apply source-specific headers (referer, user-agent mimicry)
  const headers = new Headers(options?.headers)
  headers.set('Referer', `https://${allowedDomain}/`)
  // ... required headers

  // 3. Execute fetch
  return fetch(url, { ...options, headers })
}
```

**Never** allow raw `fetch()` in source scripts.

### 3. Restricted API Surface / API 面限制

Only these APIs are exposed to source scripts:

| API / API | Purpose / 用途 | Wrapped? / 包装 |
|-----------|----------------|-----------------|
| `fetch` | Network requests | ✅ Via `safeFetch` with domain check |
| `cheerio` | HTML parsing | ✅ Loaded from npm bundle |
| `crypto` | Hashing, random | ✅ Subset exposed |
| `utils` | Helper functions | ✅ Custom utility library |

**Explicitly NOT available**:
- `eval`, `new Function`, `setTimeout`, `setInterval`
- `XMLHttpRequest`, `WebSocket`, `EventSource`
- `File`, `Blob`, `FormData` (except via fetch body)
- `navigator`, `location`, `history`
- Any browser extension APIs

### 4. Error Containment / 错误隔离

Worker crashes must not crash the main thread.

**Required Pattern**:
```typescript
// In worker message handler:
worker.onmessage = async (event) => {
  try {
    const result = await handleMessage(event.data)
    worker.postMessage({ success: true, result })
  } catch (error) {
    // Serialize error, don't leak internals
    worker.postMessage({
      success: false,
      error: {
        message: error.message,
        code: error.code // Custom error codes only
      }
    })
  }
}
```

Source scripts run in their own try/catch. Errors propagate to main thread as structured data, not exceptions.

### 5. Script Validation / 脚本验证

Before executing downloaded script:

1. **Content-Type Check**: Must be `application/javascript` or `text/javascript`
2. **Size Limit**: Max 100KB (configurable)
3. **Checksum** (optional): Compare with known good hash
4. **Static Analysis**: AST scan for forbidden patterns (eval, DOM refs)
5. **Timeout**: Script load must complete within 5s

If any check fails → reject script, log warning, continue.

## Code Review Checklist / 代码审查清单

Every change to `packages/sandbox/src/` must be checked:

### Security
- [ ] No DOM API references (`window`, `document`, `localStorage`)
- [ ] All fetch calls use `safeFetch` wrapper
- [ ] Input validation on all message handlers
- [ ] No `eval()` or `new Function()`
- [ ] No dynamic `import()` of untrusted code
- [ ] Error messages don't leak internal paths/structure

### Architecture
- [ ] Worker termination handled (cleanup on error)
- [ ] Message types validated (discriminated unions)
- [ ] Large data transfer avoided (structured cloning limits)
- [ ] Memory leaks: no circular references in messages

### Testing
- [ ] Security tests included (DOM access attempts blocked, etc.)
- [ ] Error recovery tested
- [ ] Resource limits tested (memory, timeouts)

## Pattern Library / 模式库

### ✅ Safe - Allowed Pattern / 安全模式

**Worker message handling**:
```typescript
interface WorkerMessage {
  type: 'search' | 'detail' | 'chapter'
  payload: SearchParams | DetailParams | ChapterParams
}

worker.onmessage = async (event: MessageEvent<WorkerMessage>) => {
  const { type, payload } = event.data

  switch (type) {
    case 'search':
      return await search(payload)
    case 'detail':
      return await getDetail(payload)
    case 'chapter':
      return await getChapterImages(payload)
  }
}
```

**Sanitized error propagation**:
```typescript
class SandboxError extends Error {
  constructor(
    public code: 'NETWORK_ERROR' | 'PARSE_ERROR' | 'SCRIPT_ERROR',
    message: string,
    public details?: Record<string, unknown>
  ) {
    super(message)
  }
}

// Only serialize safe fields
worker.postMessage({
  error: {
    code: err.code,
    message: err.message,
    // No stack traces in production
  }
})
```

### ❌ Unsafe - Forbidden Pattern / 危险模式

**DOM access attempt**:
```typescript
// ❌ NEVER
const viewportWidth = window.innerWidth
const html = document.documentElement.outerHTML

// ✅ If script needs viewport info, pass from main thread as initialization message
```

**Unvalidated fetch**:
```typescript
// ❌ NEVER
const resp = await fetch(userProvidedUrl)

// ✅ Use safeFetch with explicit whitelist
const resp = await safeFetch('manga-source.example.com', userProvidedUrl)
```

**Unbounded async**:
```typescript
// ❌ NEVER - infinite loop in worker
while (true) { await fetch(...) }

// ✅ Always have timeout/count limit
for (let i = 0; i < MAX_PAGES; i++) {
  // bounded iterations
}
```

## Testing Requirements / 测试要求

All sandbox code must have:

1. **Unit tests** for message routing, error handling
2. **Integration tests** for script loading and execution
3. **Security tests** specifically:
   ```typescript
   test('script cannot access window', async () => {
     const result = await worker.execute('window.innerWidth')
     expect(result).toThrow('window is not defined')
   })

   test('fetch outside whitelist rejected', async () => {
     await expect(
       worker.execute('fetch("https://evil.com/steal")')
     ).rejects.toThrow('Domain not whitelisted')
   })
   ```

## Incident Response / 事件响应

If sandbox escape is suspected:

1. **Immediate**: Disable affected source script(s) in index
2. **Investigate**: Check worker logs for unauthorized access attempts
3. **Patch**: Tighten whitelist, add additional validation
4. **Audit**: Review all source scripts from that provider
5. **Notify**: Inform users if security implications

---

*These rules are not suggestions - they are mandatory security requirements. Violations will fail code review.*
