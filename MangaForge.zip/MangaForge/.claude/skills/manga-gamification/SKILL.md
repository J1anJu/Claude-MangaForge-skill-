---
name: manga-gamification
description: Design and implement engagement mechanics: achievements, streaks, levels, reading statistics
---

# Manga Gamification / 游戏化系统

## Activation / 激活条件

Triggers when user discusses:
- Achievements or badges
- Reading streaks or consecutive days
- Levels, XP, progression systems
- Reading statistics or metrics
- User engagement features
- Leaderboards or social features

Chinese triggers: "成就", "等级", "XP", "连续阅读", "streak", "统计", "stats", "游戏化"

## Core Systems / 核心系统

### 1. Reading Streak / 连续阅读

Track consecutive calendar days with reading activity.

**Rules**:
- A "reading day" = any chapter completed on that calendar date
- Streak maintained if user reads at least once per day
- Streak breaks after 24h past midnight local time with no activity
- Optional: "streak freeze" or "make-up day" mechanics for premium users

**Data Model**:
```typescript
interface DailyReadingRecord {
  date: string;           // ISO date: YYYY-MM-DD
  chaptersRead: number;   // Chapters completed this day
  minutesRead: number;    // Total reading time
  goalMet: boolean;       // Daily goal achieved?
}

interface StreakSummary {
  currentStreak: number;      // Active consecutive days
  longestStreak: number;      // All-time best
  totalReadingDays: number;   // Days with any reading
  streakGoal: number;         // Target consecutive days (configurable)
}
```

**Calculation** (today-relative):
```typescript
function calculateCurrentStreak(records: DailyReadingRecord[]): number {
  const sorted = records.sort((a, b) =>
    new Date(b.date).getTime() - new Date(a.date).getTime()
  )

  let streak = 0
  let currentDate = new Date().toDateString()

  for (const record of sorted) {
    const recordDate = new Date(record.date).toDateString()

    if (recordDate === currentDate && record.goalMet) {
      streak++
    } else if (recordDate === addDays(new Date(currentDate), -1).toDateString()) {
      currentDate = recordDate
      streak++
    } else {
      break // Gap detected
    }
  }

  return streak
}
```

### 2. Achievements / 成就系统

Milestone-based badges that recognize reading accomplishments.

**Achievement Structure**:
```typescript
interface AchievementDefinition {
  id: string;              // Unique identifier
  title: string;           // Display name
  description: string;     // What it's for
  icon: string;            // SVG name or URL
  category: 'reading' | 'exploration' | 'social' | 'collection';

  // Condition definition
  condition: {
    type: 'cumulative' | 'single' | 'streak' | 'completion';
    metric: 'chapters' | 'pages' | 'series' | 'genres' | 'days';
    target: number;        // Required amount
    additional?: {         // Optional modifiers
      consecutiveDays?: number;  // For streak achievements
      unique?: boolean;          // Count unique only (e.g., unique genres)
    }
  };

  // Progression tracking (for progressive achievements)
  progressive?: boolean;   // Show progress bar?
  hidden?: boolean;        // Secret achievements
}

interface UnlockedAchievement {
  achievementId: string;
  unlockedAt: Date;
  progressSnapshot?: number; // Progress at unlock (for progressive)
}
```

**Common Achievement Ideas**:
- First reading session (`chapters >= 1`)
- Reading marathon (`chapters >= 100`)
- Genre explorer (`uniqueGenres >= 5`)
- Series completist (`seriesCompleted >= 10`)
- Weekend warrior (`readOnWeekends >= 4 weeks in a row`)
- Night owl (`readingAfterMidnight >= 10 times`)
- Speed reader (`pagesPerHour > threshold`)

### 3. Levels & XP / 等级经验

Progression system using experience points.

**XP Sources**:
```typescript
const XP_RATES = {
  chapter_complete: 50,      // Base XP per chapter
  page_read: 1,              // Per page (alternative)
  streak_maintained: 100,    // Bonus for maintaining streak
  achievement_unlocked: 200, // Bonus per achievement
  series_completed: 500,     // Big milestone bonus
} as const
```

**Level Curve** (exponential):
```typescript
// Level N requires: base × multiplier^(N-1)
const BASE_XP = 100
const MULTIPLIER = 1.5

function xpForLevel(level: number): number {
  return Math.floor(BASE_XP * Math.pow(MULTIPLIER, level - 1))
}

function levelFromXP(totalXP: number): number {
  let level = 1
  while (totalXP >= xpForLevel(level + 1)) {
    level++
  }
  return level
}

// Example progression:
// Level 1: 0
// Level 2: 100
// Level 3: 150
// Level 4: 225
// Level 10: ~2584 XP
```

**Level Benefits** (optional):
- Higher levels unlock badge frame styles
- Subtle profile customization options
- Priority support (if applicable)

### 4. Reading Statistics / 阅读统计

Comprehensive metrics dashboard:

```typescript
interface ReadingStats {
  // Lifetime totals
  totalChapters: number;
  totalPages: number;
  totalSeries: number;
  totalMinutes: number;

  // Time-based aggregates
  thisWeek: { chapters: number; minutes: number };
  thisMonth: { chapters: number; minutes: number };
  thisYear: { chapters: number; minutes: number };

  // Averages
  avg ChaptersPerSession: number;
  avg MinutesPerSession: number;
  avg PagesPerChapter: number;

  // Preferences
  favoriteGenre: string | null;
  preferredReadingMode: 'scroll' | 'paged' | 'webtoon';

  // Comparisons
  percentileAmongUsers?: number; // Optional: compare to peers
}
```

### 5. Collections / 收藏系统

Track series completion status:

```typescript
interface SeriesCollection {
  comicId: string;
  title: string;
  coverUrl: string;
  totalChapters: number;
  chaptersRead: number;
  startedAt: Date;
  completedAt?: Date;
  isDropped: boolean;
  dropReason?: string;
  rating?: 1-5; // User's personal rating
  notes?: string;
}
```

## Storage Design / 存储设计

### Dexie Schema / 数据库表结构

```typescript
import Dexie, { Table } from 'dexie'

export class MangaGamificationDB extends Dexie {
  readingProgress!: Table<DailyReadingRecord>
  streaks!: Table<StreakSummary>
  achievements!: Table<AchievementDefinition>  // Static definitions
  unlockedAchievements!: Table<UnlockedAchievement>
  levels!: Table<{ level: number; xpRequired: number }>
  stats!: Table<ReadingStats>
  collections!: Table<SeriesCollection>

  constructor() {
    super('manga-gamification')
    this.version(1).stores({
      readingProgress: '++id, date, [date+userId]',
      streaks: 'userId',
      achievements: 'id, category',
      unlockedAchievements: '++id, achievementId, unlockedAt, [achievementId+userId]',
      levels: 'level',
      stats: 'userId',
      collections: '++id, comicId, [comicId+userId]'
    })
  }
}
```

### Sync Strategy / 同步策略

Local-first with optional cloud sync:

```typescript
// Immediate local write, async cloud sync
async recordChapterComplete(comicId: string) {
  // 1. Update local DB (fast, <50ms)
  await this.db.readingProgress.add({
    date: todayISO(),
    chaptersRead: 1,
    minutesRead: 0, // Will be updated separately
    goalMet: true
  })

  // 2. Recalculate stats (async, fire-and-forget)
  this.recalculateStats().catch(console.error)

  // 3. Sync to cloud if user logged in (background)
  if (this.userId) {
    this.cloudSync.queue('chapter_complete', { comicId, timestamp: Date.now() })
  }
}
```

## UI Components / UI组件

### Stats Dashboard / 统计仪表板
```
┌─────────────────────────────────────┐
│  📊 Reading Statistics              │
├─────────────────────────────────────┤
│  🔥 7-day streak                   │
│  📚 142 chapters read              │
│  ⏱️  48.5 hours total              │
│  🏆 12 achievements unlocked       │
│  ⬆️  Level 15 → 16 (450/600 XP)    │
└─────────────────────────────────────┘
```

### Achievements Grid / 成就网格
```
┌─────────────────────────────────────┐
│  🏆 Achievements (12/50)           │
├─────────────────────────────────────┤
│  [🔓] First Chapter                │
│  [🔓] Genre Explorer               │
│  [🔒] 100 Chapters           (65%) │
│  [🔒] Weekend Warrior       (3/4)  │
│  [🔓] Night Reader                │
└─────────────────────────────────────┘
```

### Streak Calendar / 连续日历
Visual grid showing last 30 days with reading activity indicators.

### Level Progress / 等级进度
Progress bar showing XP toward next level, with:
- Current level badge
- Next level preview
- XP earned / XP required

## Integration Points / 集成点

### Hook into Reading Flow / 阅读流程集成

```typescript
// In ReaderPage when chapter is marked complete:
onChapterComplete() {
  // 1. Record reading session
  gamification.recordSession({
    comicId: this.comicId,
    chapterId: this.chapterId,
    pages: this.totalPages,
    minutes: this.readingTime
  })

  // 2. Check achievements (triggers toast if unlocked)
  const newlyUnlocked = await gamification.checkAchievements()
  if (newlyUnlocked.length > 0) {
    this.showToast(/* achievement notification */)
  }

  // 3. Update stats in background
  gamification.recalculateStats()
}
```

### Privacy Considerations / 隐私考虑

- All gamification data stored locally by default
- Cloud sync opt-in only
- No statistics shared with other users unless leaderboards explicitly enabled
- User can export/delete their gamification data

## Design Guidelines / 设计指南

### Visual Style
- Playful but subtle (don't distract from reading)
- Use gold/yellow for achievements, orange for streaks
- Smooth animations (250-400ms)
- Celebrate milestones with celebratory confetti (optional)

### Placement
- Stats dashboard: in profile/settings page
- Achievement unlocks: toast notification, detail in profile
- Streak: prominent on home screen ("your streak: X days")
- Level: small indicator in header/nav

### Avoid
- Notifications during reading (except streaks)
- Obtrusive animations
- Making reading feel like work (keep it fun, optional)
