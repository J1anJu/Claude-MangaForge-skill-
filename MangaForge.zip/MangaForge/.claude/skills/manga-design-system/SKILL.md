---
name: manga-design-system
description: Generate comprehensive design system specifications for manga reader UI
---

# Manga Design System / 设计系统生成

## Activation / 激活条件

Triggers when user requests:
- Design system specifications
- UI theme recommendations
- Color palette suggestions
- Typography guidance
- Component styling guidelines
- "Design" / "UI" / "theme" / "appearance" discussions

Chinese triggers: "设计系统", "UI", "主题", "配色", "风格", "视觉"

## Purpose / 目的

Generate a complete, production-ready design system tailored specifically for manga reading applications. Provide concrete specifications that can be directly implemented in Vue components and Tailwind configuration.

## Design System Structure / 设计系统结构

Generated output creates `design-system/MASTER.md` with these sections:

```
design-system/
├── MASTER.md              # Global design tokens (source of truth)
├── tokens.css             # CSS custom properties (optional)
├── tailwind.config.js     # Tailwind theme extension (optional)
└── pages/
    ├── reader.md          # Reader page overrides (optional)
    ├── library.md         # Library/bookshelf overrides
    └── discovery.md       # Discovery page overrides
```

**Hierarchy Rules**:
1. Page-specific files (e.g., `pages/reader.md`) override MASTER
2. If page file doesn't exist, use MASTER exclusively
3. MASTER is the single source of truth for cross-page consistency

## Design Recommendations / 设计建议

### Product Classification / 产品分类

Manga Reader maps to:
- **Category**: Content Consumption / Media Reading
- **Sub-category**: Image-heavy application
- **Use Context**: Long-form reading, often in low-light environments
- **Primary Interaction**: Touch gestures, scroll/swipe navigation

### Recommended Pattern / 推荐模式

**Pattern**: Content-First + Navigation-Dense + Settings-Accessible

**Layout Structure**:
```
┌──────────────────────────────────────────┐
│ ← Home  Search  ☰ Library  Settings 👤   │ ← Top nav, always visible
├──────────────────────────────────────────┤
│                                          │
│  ┌─ Continue Reading ─────────────┐     │
│  │  [Cover] Title (Ch. 15)         │     │ ← Card-based
│  │  Progress bar                   │     │
│  └─────────────────────────────────┘     │
│                                          │
│  ┌─ Recommended ───────────────────┐     │
│  │  [Grid of 4 covers]             │     │ ← Bento grid pattern
│  └─────────────────────────────────┘     │
│                                          │
│  ┌─ Genres / Categories ──────────┐     │
│  │  [Chips: Action, Romance...]   │     │ ← Horizontal scroll
│  └─────────────────────────────────┘     │
│                                          │
└──────────────────────────────────────────┘
```

### Style Priority / 风格优先级

**Primary Style**: Dark Mode (OLED Optimized) + Minimalism

**Why**:
- Manga is typically read at night / in low light
- OLED displays benefit from pure black
- Minimalism reduces visual noise, focuses on artwork
- Battery efficient on mobile devices

**Secondary Styles** (as accents):
- Bento Grid for content recommendations
- Glassmorphism for modal dialogs (subtle)
- Soft shadows for depth (not heavy)

### Color Scheme / 配色方案

#### Backgrounds / 背景
```css
--bg-primary: #000000     /* Pure black for OLED */
--bg-secondary: #121212   /* Slightly lighter for cards */
--bg-elevated: #1E1E1E   /* Floating elements, modals */
--border-subtle: #2D2D2D /* 1px borders, dividers */
```

#### Interactive Colors / 交互色
```css
--color-primary: #3B82F6     /* Blue - main actions */
--color-primary-hover: #2563EB
--color-primary-active: #1D4ED8

--color-secondary: #8B5CF6   /* Purple - secondary actions */
--color-accent: #F59E0B       /* Amber - favorites, highlights */
--color-success: #10B981      /* Green - completion */
--color-error: #EF4444        /* Red - errors, alerts */
--color-warning: #F59E0B      /* Amber - warnings */
```

#### Text / 文字
```css
--text-primary: #FFFFFF       /* Main text, 21:1 contrast */
--text-secondary: #E5E7EB     /* Body text, 15:1 contrast */
--text-muted: #9CA3AF         /* Helper text, 6:1 contrast */
--text-disabled: #6B7280      /* Disabled state, 4.5:1 contrast */
```

**Contraindications / 避免**:
- No light backgrounds for primary mode (OLED waste)
- No neon colors (eye strain during long reading)
- No pure white text on dark (use #F5F5F5 instead of #FFFFFF for comfort)

### Typography / 排版

#### UI Fonts / 界面字体
```css
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
             "Helvetica Neue", Arial, "Noto Sans SC", sans-serif;
```

#### Reading Fonts / 阅读字体
```css
font-family: "Noto Sans SC", "PingFang SC", "Microsoft YaHei",
             "Source Han Sans CN", system-ui, sans-serif;
```

#### Type Scale / 字号比例
| Element / 元素 | Size / 大小 | Line Height / 行高 | Weight / 字重 |
|---------------|-------------|-------------------|---------------|
| H1 (Page title) | 28px (1.75rem) | 1.3 | 600 |
| H2 (Section) | 24px (1.5rem) | 1.4 | 600 |
| H3 (Card title) | 18px (1.125rem) | 1.4 | 600 |
| Body (regular) | 16px (1rem) | 1.6 | 400 |
| Body (reading) | 18px (1.125rem) | 1.8 | 400 |
| Caption / 说明 | 14px (0.875rem) | 1.5 | 400 |
| Small / 小字 | 12px (0.75rem) | 1.4 | 400 |

**Reading Content Specific**:
```css
.reader-content,
.reader-text-layer {
  font-size: 18px;
  line-height: 1.8;
  max-width: 800px; /* Prevents overly long lines */
  letter-spacing: 0.02em; /* Slightly increased for Chinese */
  word-break: break-all; /* For Chinese text without spaces */
}
```

### Spacing System / 间距系统

```css
--space-1: 4px;   /* 0.25rem */
--space-2: 8px;   /* 0.5rem */
--space-3: 12px;  /* 0.75rem */
--space-4: 16px;  /* 1rem - base unit */
--space-5: 24px;  /* 1.5rem */
--space-6: 32px;  /* 2rem */
--space-8: 48px;  /* 3rem */
--space-10: 64px; /* 4rem */
--space-12: 96px; /* 6rem */
```

**Component Spacing**:
- Button padding: `12px 24px` (vertical / horizontal)
- Card padding: `16px`
- List item: `16px` vertical with `1px` divider
- Section spacing: `--space-6` (32px) between major sections

### Border Radius / 圆角

```css
--radius-sm: 4px;    /* Small badges, tags */
--radius-md: 8px;    /* Buttons, cards, inputs */
--radius-lg: 12px;   /* Modals, dialogs, large cards */
--radius-full: 9999px; /* Pills, circular icons, avatars */
```

### Shadows / 阴影

Dark mode shadows need more intensity:

```css
--shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.5);
--shadow-md: 0 4px 6px rgba(0, 0, 0, 0.6);
--shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.7);
--shadow-xl: 0 20px 25px rgba(0, 0, 0, 0.8);
```

### Transitions / 动画

```css
--duration-fast: 150ms;
--duration-normal: 250ms;
--duration-slow: 400ms;

--ease-default: cubic-bezier(0.4, 0, 0.2, 1);
--ease-smooth: cubic-bezier(0.25, 0.1, 0.25, 1);
--ease-bounce: cubic-bezier(0.34, 1.56, 0.64, 1); /* For achievements */
```

**Use by Context**:
- Button hover: `150ms ease-default`
- Page transitions: `250ms ease-smooth`
- Modal enter: `300ms ease-smooth`
- Achievement unlock: `400ms ease-bounce`
- Skeleton loading: `800ms infinite ease-default`

## Reading Mode Specialization / 阅读模式特化

### Scroll Mode (Vertical)
```css
.reader-scroll {
  overflow-y: auto;
  scroll-behavior: smooth; /* For anchor jumps */
  -webkit-overflow-scrolling: touch; /* iOS momentum */
  scroll-snap-type: y optional; /* Optional for page breaks */
}
```

### Paged Mode (Horizontal Flip)
```css
.reader-paged {
  display: flex;
  overflow-x: auto;
  scroll-snap-type: x mandatory;
  scroll-behavior: smooth;
}
.reader-page {
  scroll-snap-align: start;
  flex: 0 0 100vw; /* Full viewport width */
  min-height: 100vh;
}
```

### Webtoon Mode (Continuous Long)
```css
.reader-webtoon {
  display: flex;
  flex-direction: column;
}
.reader-webtoon img {
  width: 100%;
  height: auto;
  display: block;
}
```

## Component Styles / 组件样式

### Buttons / 按钮
```css
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 12px 24px;
  border-radius: var(--radius-md);
  font-weight: 500;
  cursor: pointer;
  transition: all var(--duration-fast) var(--ease-default);
}

.btn-primary {
  background: var(--color-primary);
  color: white;
}
.btn-primary:hover {
  background: var(--color-primary-hover);
}
.btn-primary:active {
  background: var(--color-primary-active);
  transform: scale(0.98);
}

.btn-ghost {
  background: transparent;
  color: var(--text-secondary);
}
.btn-ghost:hover {
  background: rgba(255, 255, 255, 0.1);
}
```

### Cards / 卡片
```css
.card {
  background: var(--bg-secondary);
  border-radius: var(--radius-md);
  padding: 16px;
  border: 1px solid var(--border-subtle);
  /* Optional: subtle shadow on hover */
  transition: box-shadow var(--duration-normal) var(--ease-default);
}
.card:hover {
  box-shadow: var(--shadow-md);
}
```

### Chips / 标签
```css
.chip {
  display: inline-flex;
  align-items: center;
  padding: 6px 12px;
  border-radius: var(--radius-full);
  font-size: 14px;
  background: var(--bg-elevated);
  color: var(--text-secondary);
  cursor: pointer;
  transition: all var(--duration-fast);
}
.chip.active {
  background: var(--color-primary);
  color: white;
}
```

### Progress Bar / 进度条
```css
.progress-bar {
  height: 4px;
  background: var(--bg-elevated);
  border-radius: var(--radius-full);
  overflow: hidden;
}
.progress-bar-fill {
  height: 100%;
  background: var(--color-primary);
  border-radius: var(--radius-full);
  transition: width var(--duration-normal) var(--ease-smooth);
}
```

## Pre-Delivery Checklist / 交付前检查清单

### Accessibility / 可访问性
- [ ] All text has ≥ 4.5:1 contrast ratio (use tools to verify)
- [ ] Interactive elements have `:focus` styles
- [ ] Touch targets ≥ 44×44px (visual size + padding)
- [ ] `prefers-reduced-motion` media query respected
- [ ] Images have `alt` attributes (or `alt=""` if decorative)
- [ ] Form inputs have associated `<label>` or `aria-label`
- [ ] Color is not the only means of conveying information

### Responsiveness / 响应式设计
- [ ] Layout adapts at breakpoints: 375px, 768px, 1024px, 1440px
- [ ] Touch targets appropriately sized on mobile
- [ ] Text doesn't overflow horizontal bounds
- [ ] Images scale appropriately (max-width: 100%)

### Performance / 性能
- [ ] Animations use `transform` and `opacity` (GPU accelerated)
- [ ] No layout thrashing from animations
- [ ] Images have appropriate `loading` attributes

### Reading Experience / 阅读体验
- [ ] True black backgrounds for OLED (`#000000` not `#111111`)
- [ ] No pure white text (use `#F5F5F5` instead of `#FFFFFF`)
- [ ] Line height ≥ 1.6 for reading content
- [ ] No animations during reading mode (book page turn exception)

### Cross-Platform / 跨平台
- [ ] Works in Chrome, Firefox, Safari, Edge
- [ ] PWA install banner appears on eligible browsers
- [ ] Capacitor build succeeds for Android/iOS
- [ ] No web-only APIs used in Capacitor builds

---

*This skill generates design specifications. No manual implementation - just review output and apply to components.*
