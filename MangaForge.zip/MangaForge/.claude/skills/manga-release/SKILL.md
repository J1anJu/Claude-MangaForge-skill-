---
name: manga-release
description: Multi-platform release orchestration for Web, Android, and iOS builds
---

# Manga Release / 发布管理

## Activation / 激活条件

Triggers when user discusses:
- Preparing for release
- Build processes for Web/Android/iOS
- Deployment strategies
- Version management
- Store submissions (Google Play, App Store)
- Hotfixes or patches

Chinese triggers: "发布", "部署", "构建", "build", "release", "打包", "版本"

## Purpose / 目的

Ensure consistent, reliable releases across all three platforms (Web PWA, Android APK/AAB, iOS IPA) with comprehensive quality gates and rollback procedures.

## Release Pipeline / 发布流程

```
Development → Staging → Production
     │           │          │
     ▼           ▼          ▼
  Feature   QA Testing  Public Release
  Branches   (Multi-platform)
```

### Phase 1: Pre-Release Quality Gate / 发布前质量关卡

All must pass:

```bash
# Code quality
pnpm typecheck              # 0 TypeScript errors
pnpm lint                   # 0 ESLint warnings
pnpm test                   # All tests passing

# Build verification
pnpm build                  # Web build succeeds
pnpm build:android          # Android build succeeds
pnpm build:ios              # iOS build succeeds
```

### Phase 2: Staging Verification / 预发布验证

Deploy to staging environment:

- **Web**: Deploy to `staging.mangareader.com`
  - PWA install tested
  - Service worker caching verified
  - E2E tests run against staging

- **Android**: Generate debug APK
  - Install on test device
  - Test all reading modes
  - Verify source scripts execute

- **iOS**: Build testflight IPA
  - Upload to TestFlight
  - Internal testers (5 min smoke)
  - External testers (24h review)

### Phase 3: Production Release / 生产发布

#### Web Deployment / 网页部署
```bash
# 1. Bump version
pnpm version patch|minor|major

# 2. Build production
pnpm build

# 3. Deploy (configured CI/CD)
# Vercel/Netlify: automatic on git push main
# Manual: upload packages/web/dist/ to hosting

# 4. Verify
curl -I https://mangareader.com/manifest.json
# Should return 200, correct cache headers
```

#### Android Deployment / 安卓部署
```bash
# 1. Build release bundle
cd packages/android
./gradlew bundleRelease      # Generates .aab
./gradlew assembleRelease    # Generates .apk

# 2. Sign bundle (keystore configured in gradle)
# Signing is automatic if keystore in place

# 3. Upload to Google Play Console
# - Generate release in internal testing first
# - Review pre-launch report
# - Promote to open testing / production

# 4. Version code incremented automatically by build
```

#### iOS Deployment / iOS 部署
```bash
# 1. Build
cd packages/ios
xcodebuild -scheme MangaReader -configuration Release

# 2. Archive in Xcode (recommended UI workflow)
# - Open MangaReader.xcworkspace
# - Product → Archive
# - Validate archive
# - Distribute to App Store

# Or command line:
xcodebuild -exportArchive \
  -archivePath build/MangaReader.xcarchive \
  -exportOptionsPlist ExportOptions.plist \
  -exportPath build/

# 3. Upload to App Store Connect
# Use Transporter or Xcode
```

## Version Management / 版本管理

### Semantic Versioning / 语义化版本

`MAJOR.MINOR.PATCH` (e.g., `2.5.1`)

- **MAJOR**: Incompatible API changes, major UX overhaul
- **MINOR**: New features, backward-compatible
- **PATCH**: Bug fixes, security updates

**All three platforms share the same version number.**

### Version File Location

`packages/web/package.json` - source of truth
All platform-specific manifests pull from here.

### Pre-version Bump Checklist

Before running `pnpm version` or manual bump:

- [ ] CHANGELOG.md updated with unreleased changes
- [ ] No merge conflicts in pending changes
- [ ] All tests passing on CI
- [ ] Breaking changes documented

## Hotfix Procedure / 热修复流程

For critical production issues:

```
1. Create hotfix branch from current release tag
   git checkout -b hotfix/v1.2.3-broken-search
   git checkout v1.2.3

2. Apply minimal fix (include test!)
   # ... fix code ...
   # ... add regression test ...

3. Verify on local/staging
   pnpm test
   pnpm build
   # smoke test

4. Bump patch version
   pnpm version patch --no-git-tag-version
   git add -A
   git commit -m "fix: broken search on Android (closes #123)"
   git tag v1.2.4

5. Deploy hotfix immediately to production
   # Follow Phase 3 deployment steps

6. Cherry-pick to main for next release
   git checkout main
   git cherry-pick <commit-hash>
```

## Rollback Strategy / 回滚策略

If production issues detected post-release:

### Web
- CI/CD rollback to previous deployment (one-click on Vercel/Netlify)
- Disable new service worker (force update)

### Android
- Staged rollout: 1% → 10% → 50% → 100%
- If issue detected: pause rollout, roll back percentage
- Emergency: new release with fix

### iOS
- Remove build from App Store Connect review
- Submit replacement binary (App Store review required)
- Use phased release (7 days) for gradual rollout

## Post-Release Checklist / 发布后清单

Within 1 hour of production release:

- [ ] Production URL accessible
- [ ] PWA install banner appears
- [ ] Service worker active (check DevTools)
- [ ] Error monitoring baseline (Sentry) zero new errors
- [ ] Analytics tracking (page views, events)
- [ ] Manual smoke test on real device

Within 24 hours:
- [ ] Monitor crash reports (Firebase Crashlytics / Sentry)
- [ ] Check user feedback (store reviews, social media)
- [ ] Update status page if issues

## Release Announcement / 发布公告

For minor/major releases:

```
# Draft Release Notes (CHANGELOG.md format)

## [1.3.0] - 2026-05-20

### Added / 新增
- Reading streak tracking with achievements
- Series update notifications
- Dark theme customization options

### Changed / 变更
- Improved source script performance (30% faster searches)
- Redesigned reader controls (more intuitive gestures)

### Fixed / 修复
- Fixed occasional page loading errors
- Fixed bookmark sync across devices
- Fixed iOS safe area handling

### Known Issues / 已知问题
- None
```

## Storage Versioning / 存储版本

If IndexedDB schema changes:

1. Increment `db.version()`
2. Add upgrade steps:
   ```typescript
   db.version(3).stores({
     readingHistory: '++id, comicId, timestamp',
     ongoingSeries: 'comicId, lastReadAt',
     achievements: 'id, unlockedAt',
     stats: 'userId'  // NEW table
   })
   ```
3. Test migration from previous version
4. Document in `docs/UPGRADE.md` if manual migration needed

## CI/CD Integration / 持续集成

Recommended GitHub Actions workflow:

```yaml
name: Release CI

on:
  push:
    branches: [main, release/*]
  pull_request:
    branches: [main]

jobs:
  typecheck:
    runs-on: ubuntu-latest
    steps: [pnpm typecheck]

  lint:
    runs-on: ubuntu-latest
    steps: [pnpm lint]

  test:
    runs-on: ubuntu-latest
    steps:
      - pnpm test:unit
      - pnpm test:integration

  build-web:
    needs: [test]
    runs-on: ubuntu-latest
    steps:
      - pnpm build
      - upload-artifact: packages/web/dist/

  build-android:
    needs: [test]
    runs-on: macos-latest  # For Gradle
    steps:
      - pnpm build:android
      - upload-artifact: app-release.aab

  build-ios:
    needs: [test]
    runs-on: macos-latest
    steps:
      - pnpm build:ios
      - upload-artifact: MangaReader.ipa
```

---

*This skill orchestrates the release process. Execute these steps methodically for reliable, repeatable releases across all platforms.*
