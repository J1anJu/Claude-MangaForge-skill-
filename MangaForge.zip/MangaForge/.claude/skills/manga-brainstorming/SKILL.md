---
name: manga-brainstorming
description: Explore feature ideas, analyze requirements, and create design briefs for manga reader development
---

# Manga Brainstorming / 功能规划

## Activation / 激活条件

Triggers when user discusses:
- New feature ideas
- Project requirements
- User experience improvements
- Project setup or initialization
- Problem statements needing solutions

Chinese triggers: "规划", "设计", "想法", "功能", "feature", "proposal", "idea"

## Purpose / 目的

Guide feature ideation from broad concept to actionable design brief. Consider multiple perspectives: UX, gamification, technical feasibility, platform constraints.

## Process / 流程

### Phase 1: Vision Clarification / 愿景澄清

Ask targeted questions to understand the problem:

```
📋 Key Questions / 关键问题:
────────────────────────────────────────────────────────
1. Who are we building this for? / 目标用户是谁？
   - Casual readers / 休闲读者
   - Power users / 重度用户
   - Specific genre fans / 特定题材粉丝

2. What problem are we solving? / 要解决什么问题？
   - Current pain point / 当前痛点
   - Desired outcome / 期望效果

3. What's the primary goal? / 主要目标是什么？
   - User retention (engagement) / 用户留存
   - Acquisition (new users) / 拉新
   - Revenue (monetization) / 变现
   - Differentiation (unique UX) / 差异化

4. Platform priority? / 平台优先级？
   - Web (PWA) / 网页
   - Android / 安卓
   - iOS / iOS

5. Success criteria? / 成功标准？
   - Quantitative: DAU ↑, session time ↑, etc.
   - Qualitative: user feedback themes
```

### Phase 2: Multi-Domain Exploration / 多领域探索

Simultaneously evaluate:

**UX/UI Considerations / 用户体验**
- How does this fit into existing user flows?
- What design system components apply?
- Does it require new visual patterns?
- Accessibility implications?

**Gamification Potential / 游戏化潜力**
- Could this involve streaks, achievements, levels?
- What metrics would be meaningful?
- How to make it fun but not distracting?

**Technical Feasibility / 技术可行性**
- IndexedDB storage requirements
- Web Worker compatibility (sandbox constraints)
- PWA capabilities needed
- Platform-specific limitations (Capacitor vs Web)

**Scope Definition / 范围界定**
- MVP (minimum viable product)
- Phase 2 enhancements
- Nice-to-have stretch goals

### Phase 3: Design Brief Creation / 设计文档

Create `docs/DESIGN_BRIEF_[feature-name].md`:

```markdown
# Design Brief: [Feature Name] / 功能名称

## 1. Problem Statement / 问题陈述
What user need does this address? / 这解决什么用户需求？

## 2. Target Personas / 目标用户画像
- **Persona 1**: [描述] / [Description]
- **Persona 2**: [描述] / [Description]

## 3. User Journey / 用户旅程
Step-by-step interaction flow:
1. [Step] - [What user sees/does]
2. ...

## 4. MVP Scope / MVP 范围
**In scope for v1:**
- [ ] Feature A
- [ ] Feature B

**Out of scope (future phases):**
- [ ] Feature C
- [ ] Feature D

## 5. Design System Reference / 设计系统参考
- Base: `design-system/MASTER.md`
- Custom additions: [specific colors, components needed]

## 6. Gamification Elements / 游戏化元素
- [ ] Achievements related to this feature
- [ ] Streak considerations
- [ ] Stats to track
- [ ] Level/XP implications

## 7. Technical Considerations / 技术考量
- Storage: IndexedDB tables needed
- Sandbox: Any script execution?
- Performance: Expected load times, preloading needs
- Platforms: Web-only or cross-platform

## 8. Success Metrics / 成功指标
- Primary KPI: [e.g., % of users using feature]
- Secondary: [engagement duration, retention impact]

## 9. Risks & Dependencies / 风险与依赖
- Technical risks: [performance, security]
- Design risks: [accessibility, user confusion]
- External dependencies: [APIs, libraries]
```

## Example Outputs / 示例输出

### Example 1: "Continue Reading" Shelf
**Prompt**: 我想添加一个"继续阅读"书架功能

**Output includes**:
- Personas: Casual readers who read multiple series
- Journey: Home → Shelf tap → Series → Last page
- MVP: Last 3 series, cover + title + chapter
- Stretch: Progress bars, "time since last read", sort options
- Gamification: Could this count toward streaks?
- Storage: Update `ongoingSeries` table, add `lastReadAt`

### Example 2: Genre Filtering
**Prompt**: 发现页面需要按题材筛选漫画

**Output includes**:
- UX: Filter bar with genre chips, multi-select
- Design: Use existing chip components, add active states
- Tech: Store selected genres in URL query (router)
- MVP: Top 10 genres, single-select
- Stretch: Custom genre selection (from user's reading history)

## Coordination with Agents / 代理协调

Generated design briefs become input for:

- **Creative Director**: Reviews design system alignment
- **Technical Director**: Validates technical approach
- **UI Programmer**: Implements components using specs
- **QA Specialist**: Creates test plan from requirements

## Integration with Design System / 与设计系统集成

If `design-system/MASTER.md` exists:
- Reference specific design tokens (colors, spacing)
- Identify if new component patterns needed
- Note any design system updates required

If not exists:
- Recommend generating design system first
- Provide initial suggestions based on reading app patterns

## Follow-up Commands / 后续命令

After brainstorming completion, user typically proceeds:

```
/skill-test  # Verify setup if first feature

# Generate design system if not exists
Design the UI for this feature → manga-design-system

# Start implementation
/dev-story --story "feature-name"

# Create test plan
/qa-plan --feature "feature-name"
```

---

*Auto-triggers on feature planning discussions. Provides structured output for team alignment.*
