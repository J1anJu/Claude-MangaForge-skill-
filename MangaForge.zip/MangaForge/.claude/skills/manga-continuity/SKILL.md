---
name: manga-continuity
description: Track reading history, manage ongoing series, and detect updates
---

# Manga Continuity / 连续性追踪

## Activation / 激活条件

Triggers when user discusses:
- Continue reading functionality
- Reading history or bookmarks
- Series update notifications
- Bookshelf organization
- Progress tracking across devices
- "Where did I leave off?" features

Chinese triggers: "继续阅读", "书架", "历史", "更新", "bookmark", "continuity", "tracking"

## Purpose / 目的

Help readers seamlessly resume their reading, track ongoing series, and stay informed about new chapters without losing their place or forgetting what they're reading.

## Core Features / 核心功能

### 1. Reading History / 阅读历史

Complete log of every reading session:

```typescript
interface ReadingSession {
  id: string;
  userId: string;
  comicId: string;
  comicTitle: string;
  chapterId: string;
  chapterTitle: string;
  chapterIndex: number;  // Position in series
  pageNumber: number;    // Exact page (for bookmark resume)
  timestamp: Date;
  durationMs: number;    // Time spent on this session
  pagesRead: number;
}
```

**Use Cases**:
- Resume from last page
- Show reading timeline ("you read this 3 days ago")
- Calculate reading velocity (pages per minute)
- Feed for "recently read" shelf

### 2. Ongoing Series Tracking / 进行中的系列追踪

Track active series with metadata:

```typescript
interface OngoingSeries {
  comicId: string;
  title: string;
  coverUrl: string;
  author?: string;

  // Progress
  lastChapterRead: number;      // Chapter index (0-based)
  lastChapterTitle: string;
  lastReadAt: Date;
  pagesReadInChapter: number;   // For exact resume

  // Source status
  totalChaptersAtLastCheck: number;
  updateFrequency: 'daily' | 'weekly' | 'monthly' | 'irregular' | 'hiatus';
  sourceUrl: string;            // For update checks

  // UI state
  isPinned: boolean;            // User-pinned to top of shelf
  userNotes?: string;           // Personal notes
  tags: string[];               // User categorization
}
```

**Auto-calculated fields**:
- `isUpdateAvailable` = `totalChaptersNow > totalChaptersAtLastCheck`
- `chaptersRemaining` = `totalChaptersNow - lastChapterRead - 1`
- `daysSinceLastRead` = for prioritizing "continue reading" order

### 3. "Continue Reading" Shelf / 继续阅读书架

Smart shelf showing series that deserve attention:

**Prioritization Algorithm**:
```typescript
function prioritizeForContinueShelf(
  ongoing: OngoingSeries[],
  limit: number = 5
): OngoingSeries[] {
  return ongoing
    .filter(s => !s.isDropped)
    .sort((a, b) => {
      // 1. Pinned series first
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1

      // 2. Unread updates first
      const aHasUpdate = a.isUpdateAvailable
      const bHasUpdate = b.isUpdateAvailable
      if (aHasUpdate !== bHasUpdate) return aHasUpdate ? -1 : 1

      // 3. Most recent reading first
      return new Date(b.lastReadAt).getTime() - new Date(a.lastReadAt).getTime()
    })
    .slice(0, limit)
}
```

**Display** (each card):
```
┌─────────────┐
│  [Cover]    │
│  Title       │
│  Ch. 15 / 23 │  ← Progress
│  3 days ago  │  ← Recency
│  ⚠️ 2 new    │  ← Update badge (if applicable)
└─────────────┘
```

### 4. Update Detection / 更新检测

Check source indexes for new chapters:

```typescript
interface UpdateCheckResult {
  comicId: string;
  chaptersAdded: number;
  lastCheck: Date;
  checkedChapterCount: number;
  isUpdateAvailable: boolean;
}

async function checkForUpdates(series: OngoingSeries): Promise<UpdateCheckResult> {
  // 1. Fetch latest index from source
  const index = await sourceManager.getIndex(series.sourceUrl)

  // 2. Compare chapter counts
  const latestChapterCount = index.chapters.length

  const result: UpdateCheckResult = {
    comicId: series.comicId,
    chaptersAdded: latestChapterCount - series.totalChaptersAtLastCheck,
    lastCheck: new Date(),
    checkedChapterCount: latestChapterCount,
    isUpdateAvailable: latestChapterCount > series.totalChaptersAtLastCheck
  }

  // 3. If update found, update tracked total
  if (result.isUpdateAvailable) {
    series.totalChaptersAtLastCheck = latestChapterCount
    await db.ongoingSeries.put(series)
  }

  // 4. Record check history
  await db.updateChecks.add(result)

  return result
}
```

**Update Frequency**:
- Every 6 hours for active series (user reading within week)
- Once daily for dormant series (>7 days)
- Manual check via pull-to-refresh always allowed

### 5. Reading Queue / 阅读队列

Allow users to plan future reads:

```typescript
interface ReadingQueue {
  userId: string;
  items: QueueItem[];
}

interface QueueItem {
  comicId: string;
  title: string;
  coverUrl: string;
  addedAt: Date;
  priority: number;  // User-set (1=high, 5=low)
  notes?: string;
}
```

### 6. Completed & Dropped / 完成与放弃

Archive tracking:

```typescript
interface CompletedSeries {
  comicId: string;
  title: string;
  completedAt: Date;
  totalChapters: number;
  totalReadingMinutes: number;
  daysToComplete: number;  // From first to last chapter
}

interface DroppedSeries {
  comicId: string;
  title: string;
  droppedAt: Date;
  reason: 'not-interested' | 'bad-quality' | 'unfinished' | 'other';
  notes?: string;
  lastChapterRead: number;  // How far they got before dropping
}
```

### 7. Smart Notifications / 智能通知

PWA push notifications (if user grants permission):

```typescript
interface UpdateNotification {
  comicId: string;
  title: string;
  newChapters: number;
  lastReadChapter: number;
  deepLink: `manga-reader://comic/${comicId}/chapter/${chapterNum}`;
}

async function sendUpdateNotification(series: OngoingSeries) {
  if (!('serviceWorker' in navigator) || !Notification.permission === 'granted') {
    return
  }

  const notification: UpdateNotification = {
    comicId: series.comicId,
    title: series.title,
    newChapters: series.totalChaptersAtLastCheck - series.lastChapterRead,
    lastReadChapter: series.lastChapterRead + 1,
    deepLink: `manga-reader://comic/${series.comicId}`
  }

  await sw.registration.showNotification(
    `📚 ${series.title} has ${notification.newChapters} new chapter(s)!`,
    {
      body: `Continue from Chapter ${notification.lastReadChapter}`,
      data: notification,
      actions: [
        { action: 'read', title: 'Read Now' },
        { action: 'dismiss', title: 'Later' }
      ]
    }
  )
}
```

## Storage Schema / 存储表结构

```typescript
db.version(2).stores({
  // Core continuity tables
  readingHistory: '++id, comicId, chapterId, timestamp, [userId]',
  ongoingSeries: 'comicId, lastReadAt, isPinned, [userId]',
  updateChecks: 'comicId, lastCheck, [userId]',
  readingQueue: '++id, priority, addedAt, [userId]',
  completedSeries: 'comicId, completedAt, [userId]',
  droppedSeries: 'comicId, droppedAt, [userId]',

  // Indexes for queries
  readingHistory_comic: '[comicId+timestamp]',
  ongoingSeries_update: '[isUpdateAvailable+lastReadAt]'
})
```

## UX Patterns / 用户体验模式

### Home Widget / 首页小部件

"Continue Reading" section on home page:
- Shows 3-5 most relevant series
- Each card: cover, title, chapter, progress bar, update badge
- Tap to resume → open reader at last page
- Swipe left to dismiss (optional: "hide for 1 week")

### Bookshelf Views / 书架视图

Multiple tabs/categories:

| Tab / 标签 | Criteria / 标准 |
|-----------|-----------------|
| Reading / 在读 | ongoingSeries where not isDropped |
| Updated / 有更新 | ongoingSeries where isUpdateAvailable |
| Queue / 计划中 | readingQueue items |
| Completed / 已完成 | completedSeries |
| Dropped / 已弃读 | droppedSeries |

### Series Card / 系列卡片 Design

```
┌────────────────────────────┐
│  [Cover 120×160]    ⭐4.5   │
│  Series Title (truncated)  │
│  Ch. 15 / 23     ███████░░ │ ← Progress bar
│  2 days ago        🆕 2 new │ ← Status
└────────────────────────────┘
```

### Pull-to-Refresh / 下拉刷新

Shelf page gesture:
1. Pull down → "Checking for updates..."
2. Release → trigger `checkAllUpdates()`
3. Updated counts displayed, "X new chapters" toast

## Performance Considerations / 性能考虑

- **Batch update checks** - Don't check all series at once (limit 5 concurrent)
- **Debounce refreshes** - Minimum 30s between manual refresh checks
- **Cache index** - Source index cached for 1 hour (configurable)
- **Lazy load covers** - Images load when card enters viewport
- **Virtual scrolling** - For large libraries (>100 series)

## Integration with Other Systems / 与其他系统集成

### Gamification
- Reading streak updates when marking chapter complete
- "Series Completed" achievement when moving to completedSeries
- Stats dashboard pulls from continuity data

### Bookmark System
- Continuity provides the bookmark source
- User manual bookmarks = pinned ongoing series
- Auto-bookmarks = last reading position

### Source Manager
- `getIndex()` to check chapter counts
- `getChapter()` to fetch pages for reading
- Script validation continues to apply

---

*This skill provides the continuity infrastructure. Implement storage, UI components, and background sync following these specifications.*
